# CPFR KPI Tracker Starter

Clean Streamlit backbone for a sales-team CPFR KPI Tracker.

## Scope in this starter

Core KPIs only:

- `on_hand`
- `sales_last4`
- `n4w`
- `fc_final`
- `doi_days`
- `inventory_position`
- `daily_sellout_rate`
- `in_stock_flag`
- `overstock_flag`
- `necesidad` rounded to full `UxE` packages
- dashboard summary columns inspired by the KPI Tracker template:
  - Total Combinations
  - Total Inventory
  - InStock %
  - OverStock %
  - Days on Inventory
  - Combinations with under 1 package on inventory
  - Combinations with under 3 package on inventory
  - Combinations with over 3 package on inventory
  - NECESIDAD

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Recommended file flow

1. Place RL `.txt` files in `data/raw/`.
2. Configure file paths in the sidebar.
3. Click **Build / Refresh Parquet + KPIs**.
4. Use the sales-team dashboard and export filtered details.

## Main grain

The operational grain is always:

```text
store_id + client_item_nbr
```

`client_item_nbr` is kept until the end. `item_id` is added through the two-step item catalog lookup.


## KPI policy implemented in this version

The foundation KPI logic now follows the agreed business definition.

### Demand floor / daily sell-out rate

For every `store_id + client_item_nbr` combination:

```text
demand_28d_units = max(
  sales_last4,
  sales_ly_next4,
  2 * UxE
)

daily_sellout_rate = demand_28d_units / 28
```

This avoids distorted DOI for new items or low-history items by forcing a minimum demand floor of two packages.

### Inventory position

By default:

```text
inventory_position = on_hand + in_transit + in_whse
```

`on_order` is excluded by default. It can be included from the sidebar if needed.

### DOI

```text
doi_days = inventory_position / daily_sellout_rate
```

### InStock %

Each combination returns `in_stock_flag = 1` when:

```text
inventory_position > daily_sellout_rate
```

The summary `InStock %` is the percentage of combinations meeting that condition.

### OverStock %

OverStock is only evaluated when the combination has more than two packages on inventory:

```text
inventory_position > 2 * UxE
```

Then it returns `overstock_flag = 1` when:

```text
doi_days > 90
```

The summary `OverStock %` is the percentage of combinations flagged as overstock.

### NECESIDAD

Need is calculated in units but rounded up to full packages because replenishment is shipped in packages.

```text
target_inventory_units_raw = daily_sellout_rate * target_coverage_days
necesidad_raw_units = max(0, target_inventory_units_raw - inventory_position)
necesidad_packages = ceil(necesidad_raw_units / UxE)
necesidad = necesidad_packages * UxE
```

The default `target_coverage_days` is 28 days.
