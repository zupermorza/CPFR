from __future__ import annotations

from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st
import yaml

from cpfr.engine import run_pipeline
from cpfr.kpis import build_dashboard_summaries


st.set_page_config(page_title="CPFR KPI Tracker", layout="wide")


def load_config(path: str = "config.yaml") -> dict:
    p = Path(path)
    if not p.exists():
        return {}
    return yaml.safe_load(p.read_text(encoding="utf-8")) or {}


def fmt_int(x) -> str:
    try:
        return f"{float(x):,.0f}"
    except Exception:
        return "0"


def fmt_pct(x) -> str:
    try:
        return f"{float(x) * 100:,.1f}%"
    except Exception:
        return "-"


def fmt_float(x) -> str:
    try:
        return f"{float(x):,.1f}"
    except Exception:
        return "-"


cfg = load_config()
st.title(cfg.get("app", {}).get("title", "CPFR KPI Tracker"))
st.caption("Sales-team KPI tracker built on clean RL TXT ingestion, Parquet caching, and store-SKU KPI logic.")

with st.sidebar:
    st.header("Source files")
    st.caption("Use RL .txt/.csv files or Excel during testing.")

    file_paths = {
        "weekly_sellout": st.text_input("1. Weekly sell-out", cfg.get("files", {}).get("weekly_sellout", "")),
        "weekly_sellout_ly": st.text_input("2. Last year's weekly sell-out", cfg.get("files", {}).get("weekly_sellout_ly", "")),
        "current_inventory": st.text_input("3. Current total inventory", cfg.get("files", {}).get("current_inventory", "")),
        "forecast_6w": st.text_input("4. Client forecast 6W", cfg.get("files", {}).get("forecast_6w", "")),
        "item_catalog": st.text_input("5. Item catalog", cfg.get("files", {}).get("item_catalog", "")),
        "store_catalog": st.text_input("6. Store catalog", cfg.get("files", {}).get("store_catalog", "")),
        "subcat_store_ly": st.text_input("7. SubCategory-store LY sell-out", cfg.get("files", {}).get("subcat_store_ly", "")),
        "valid_combos": st.text_input("8. Valid active SKU-store combos", cfg.get("files", {}).get("valid_combos", "")),
    }

    st.header("KPI settings")
    fc_final_basis = st.selectbox("Forecast final basis", ["n6w", "n4w"], index=0)
    horizon = 6 if fc_final_basis == "n6w" else 4

    st.header("Inventory policy")
    st.caption("On Order is excluded by default, per the KPI definition.")
    policy_cfg = cfg.get("kpi_policy", {})
    include_in_transit = st.checkbox("Include In Transit in inventory position", value=bool(policy_cfg.get("include_in_transit", True)))
    include_in_whse = st.checkbox("Include In Whse in inventory position", value=bool(policy_cfg.get("include_in_whse", True)))
    include_on_order = st.checkbox("Include On Order in inventory position", value=bool(policy_cfg.get("include_on_order", False)))
    target_coverage_days = st.number_input("NECESIDAD target coverage days", min_value=1, max_value=180, value=int(policy_cfg.get("target_coverage_days", 28)), step=1)
    overstock_doi_threshold = st.number_input("OverStock DOI threshold", min_value=1, max_value=365, value=int(policy_cfg.get("overstock_doi_threshold", 90)), step=1)

    run_btn = st.button("Build / Refresh Parquet + KPIs", type="primary")

if "results" not in st.session_state:
    st.session_state["results"] = {}

if run_btn:
    with st.spinner("Building clean Parquet files and KPI tables..."):
        required = ["current_inventory", "forecast_6w", "item_catalog", "store_catalog", "valid_combos"]
        missing = [k for k in required if not file_paths.get(k)]
        if missing:
            st.error(f"Missing required paths: {', '.join(missing)}")
        else:
            st.session_state["results"] = run_pipeline(
                file_paths=file_paths,
                parquet_dir=cfg.get("paths", {}).get("parquet_dir", "data/parquet"),
                output_dir=cfg.get("paths", {}).get("output_dir", "data/outputs"),
                forecast_horizon_weeks=horizon,
                fc_final_basis=fc_final_basis,
                include_in_transit=include_in_transit,
                include_in_whse=include_in_whse,
                include_on_order=include_on_order,
                target_coverage_days=int(target_coverage_days),
                overstock_doi_threshold=float(overstock_doi_threshold),
            )
            st.success("KPI tables created.")

results = st.session_state["results"]

if not results:
    st.info("Enter file paths in the sidebar, then click **Build / Refresh Parquet + KPIs**.")
    st.stop()

kpis = results["store_item_kpis"].copy()

# Filters
st.sidebar.header("Filters")
for col, label in [
    ("store_trait", "Store Trait"),
    ("category", "Category"),
    ("brand", "Brand"),
    ("subcategory", "SubCategory"),
    ("state", "State"),
]:
    if col in kpis.columns:
        choices = sorted([x for x in kpis[col].dropna().astype(str).unique()])
        selected = st.sidebar.multiselect(label, choices)
        if selected:
            kpis = kpis[kpis[col].astype(str).isin(selected)]

filtered_summaries = build_dashboard_summaries(kpis)

tab1, tab2, tab3, tab4 = st.tabs([
    "Executive Summary",
    "Store-SKU Detail",
    "Hierarchy Summaries",
    "Data Quality",
])

with tab1:
    st.subheader("Initial KPI Tracker Summary")

    total_combos = len(kpis)
    total_inv = kpis["inventory_position"].sum() if "inventory_position" in kpis.columns else kpis.get("on_hand", pd.Series(dtype=float)).sum()
    total_sales_l4 = kpis["sales_last4"].sum() if "sales_last4" in kpis.columns else 0
    total_n4w = kpis["n4w"].sum() if "n4w" in kpis.columns else 0
    total_need = kpis["necesidad"].sum() if "necesidad" in kpis.columns else 0
    avg_doi = kpis["doi_days"].mean() if "doi_days" in kpis.columns else None
    instock_pct = kpis["in_stock_flag"].mean() if "in_stock_flag" in kpis.columns and len(kpis) else None
    overstock_pct = kpis["overstock_flag"].mean() if "overstock_flag" in kpis.columns and len(kpis) else None

    c1, c2, c3, c4, c5, c6, c7, c8 = st.columns(8)
    c1.metric("Total Combinations", fmt_int(total_combos))
    c2.metric("Total Inventory", fmt_int(total_inv))
    c3.metric("Sales Last 4W", fmt_int(total_sales_l4))
    c4.metric("N4W Forecast", fmt_int(total_n4w))
    c5.metric("Avg DOI Days", fmt_float(avg_doi))
    c6.metric("InStock %", fmt_pct(instock_pct))
    c7.metric("OverStock %", fmt_pct(overstock_pct))
    c8.metric("NECESIDAD", fmt_int(total_need))

    summary_trait = filtered_summaries.get("by_store_trait", pd.DataFrame())
    if not summary_trait.empty:
        st.markdown("### SEL STORE TRAIT")
        display = summary_trait.copy()
        display["instock_pct"] = display["instock_pct"].map(fmt_pct)
        display["overstock_pct"] = display["overstock_pct"].map(fmt_pct)
        display["doi_days"] = display["doi_days"].map(fmt_float)
        st.dataframe(display, use_container_width=True, hide_index=True)

    summary_cat = filtered_summaries.get("by_category", pd.DataFrame())
    if not summary_cat.empty:
        st.markdown("### GRS1 / Category")
        display = summary_cat.copy()
        display["instock_pct"] = display["instock_pct"].map(fmt_pct)
        display["overstock_pct"] = display["overstock_pct"].map(fmt_pct)
        display["doi_days"] = display["doi_days"].map(fmt_float)
        st.dataframe(display, use_container_width=True, hide_index=True)

    if "store_trait" in kpis.columns:
        chart_df = kpis.groupby("store_trait", as_index=False, observed=True).agg(
            inventory_position=("inventory_position", "sum"),
            n4w=("n4w", "sum"),
            fc_final=("fc_final", "sum"),
        )
        fig = px.bar(chart_df, x="store_trait", y=["inventory_position", "n4w", "fc_final"], barmode="group")
        st.plotly_chart(fig, use_container_width=True)

with tab2:
    st.subheader("Store-SKU Detail")
    detail_cols = [
        "store_id", "store_name", "store_name_catalog", "client_item_nbr", "item_id", "item_desc",
        "brand", "category", "subcategory", "store_trait", "state", "region",
        "on_hand", "in_transit", "in_whse", "on_order", "inventory_position",
        "sales_last4", "sales_ly_next4", "n4w", "fc_final",
        "demand_28d_units", "daily_sellout_rate", "doi_days",
        "in_stock_flag", "overstock_flag", "necesidad_packages", "necesidad",
    ]
    detail_cols = [c for c in detail_cols if c in kpis.columns]
    st.dataframe(kpis[detail_cols], use_container_width=True, hide_index=True)

    csv = kpis[detail_cols].to_csv(index=False, encoding="utf-8-sig")
    st.download_button("Download filtered detail CSV", data=csv, file_name="filtered_store_item_kpis.csv", mime="text/csv")

with tab3:
    st.subheader("Hierarchy Summaries")
    for key in ["summary_by_brand", "summary_by_subcategory", "summary_by_state"]:
        df = filtered_summaries.get(key.replace("summary_", ""), pd.DataFrame())
        if not df.empty:
            st.markdown(f"### {key.replace('summary_by_', '').title()}")
            display = df.copy()
            display["instock_pct"] = display["instock_pct"].map(fmt_pct)
            display["overstock_pct"] = display["overstock_pct"].map(fmt_pct)
            display["doi_days"] = display["doi_days"].map(fmt_float)
            st.dataframe(display, use_container_width=True, hide_index=True)

with tab4:
    st.subheader("Duplicate Diagnostics")
    diag = results.get("duplicate_diagnostics", pd.DataFrame())
    st.dataframe(diag, use_container_width=True, hide_index=True)
    if not diag.empty:
        st.caption("Duplicate key rate is calculated as duplicated keys / unique keys at each dataset's expected grain.")
