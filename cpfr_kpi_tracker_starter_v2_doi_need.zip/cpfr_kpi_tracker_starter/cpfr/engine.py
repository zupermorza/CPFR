from __future__ import annotations

from pathlib import Path
from typing import Dict, Tuple

import pandas as pd

from .aggregation import aggregate_duplicates, diagnostics_to_frame
from .cleaning import clean_common, coerce_numeric
from .io import read_any_table, write_parquet, export_csv
from .lookups import build_item_lookups
from .kpis import compute_sales_windows, compute_store_item_kpis, build_dashboard_summaries


def _empty() -> pd.DataFrame:
    return pd.DataFrame()


def load_clean_datasets(file_paths: Dict[str, str]) -> tuple[dict[str, pd.DataFrame], pd.DataFrame]:
    """
    Read raw files and return cleaned, grain-correct datasets plus diagnostics.
    """
    diags = []
    out: dict[str, pd.DataFrame] = {}

    # 1) Current weekly sell-out
    if file_paths.get("weekly_sellout"):
        df = clean_common(read_any_table(file_paths["weekly_sellout"]))
        df, d = aggregate_duplicates(
            df,
            keys=["store_id", "client_item_nbr", "wm_week"],
            sum_cols=["pos_qty", "pos_cost", "pos_sales"],
            keep_cols=["item_desc", "store_name", "store_trait"],
            dataset="weekly_sellout",
        )
        out["weekly_sellout"] = df
        diags.append(d)
    else:
        out["weekly_sellout"] = _empty()

    # 2) Last year's weekly sell-out
    if file_paths.get("weekly_sellout_ly"):
        df = clean_common(read_any_table(file_paths["weekly_sellout_ly"]))
        df = df.rename(columns={"pos_qty": "pos_qty_ly", "pos_cost": "pos_cost_ly", "pos_sales": "pos_sales_ly"})
        df = coerce_numeric(df, ["pos_qty_ly", "pos_cost_ly", "pos_sales_ly"])
        df, d = aggregate_duplicates(
            df,
            keys=["store_id", "client_item_nbr", "wm_week"],
            sum_cols=["pos_qty_ly", "pos_cost_ly", "pos_sales_ly"],
            keep_cols=["item_desc", "store_name", "store_trait"],
            dataset="weekly_sellout_ly",
        )
        out["weekly_sellout_ly"] = df
        diags.append(d)
    else:
        out["weekly_sellout_ly"] = _empty()

    # 3) Current inventory
    if file_paths.get("current_inventory"):
        df = clean_common(read_any_table(file_paths["current_inventory"]))
        df, d = aggregate_duplicates(
            df,
            keys=["store_id", "client_item_nbr"],
            sum_cols=["on_hand", "in_transit", "in_whse", "on_order"],
            keep_cols=["item_desc", "store_name", "store_trait"],
            dataset="current_inventory",
        )
        out["current_inventory"] = df
        diags.append(d)
    else:
        out["current_inventory"] = _empty()

    # 4) Forecast 6W
    if file_paths.get("forecast_6w"):
        df = clean_common(read_any_table(file_paths["forecast_6w"]))
        fc_cols = [f"fc_wk_{i}" for i in range(1, 7)]
        df, d = aggregate_duplicates(
            df,
            keys=["store_id", "client_item_nbr"],
            sum_cols=fc_cols,
            keep_cols=["item_desc", "store_name", "store_trait"],
            dataset="forecast_6w",
        )
        out["forecast_6w"] = df
        diags.append(d)
    else:
        out["forecast_6w"] = _empty()

    # 5) Item catalog
    if file_paths.get("item_catalog"):
        item_catalog = clean_common(read_any_table(file_paths["item_catalog"]))
        out["item_catalog"] = item_catalog
    else:
        out["item_catalog"] = _empty()

    # 6) Store catalog
    if file_paths.get("store_catalog"):
        store_catalog = clean_common(read_any_table(file_paths["store_catalog"]))
        if "store_id" in store_catalog.columns:
            store_catalog = store_catalog.drop_duplicates("store_id", keep="first")
        out["store_catalog"] = store_catalog
    else:
        out["store_catalog"] = _empty()

    # 7) Subcategory-store LY
    if file_paths.get("subcat_store_ly"):
        sub = clean_common(read_any_table(file_paths["subcat_store_ly"]))
        if "subcat_store_id" in sub.columns:
            extracted = sub["subcat_store_id"].astype(str).str.extract(r"^(\d+)(.*)$")
            sub["store_id"] = extracted[0].astype("string").str.strip()
            sub["subcategory"] = extracted[1].astype("string").str.strip()
        out["subcat_store_ly"] = sub
    else:
        out["subcat_store_ly"] = _empty()

    # 8) Valid combos
    if file_paths.get("valid_combos"):
        valid = clean_common(read_any_table(file_paths["valid_combos"]))
        valid = valid[["store_id", "client_item_nbr"]].drop_duplicates()
        out["valid_combos"] = valid
    else:
        out["valid_combos"] = _empty()

    return out, diagnostics_to_frame(diags)


def run_pipeline(
    file_paths: Dict[str, str],
    parquet_dir: str | Path = "data/parquet",
    output_dir: str | Path = "data/outputs",
    forecast_horizon_weeks: int = 6,
    fc_final_basis: str = "n6w",
    include_in_transit: bool = True,
    include_in_whse: bool = True,
    include_on_order: bool = False,
    target_coverage_days: int = 28,
    overstock_doi_threshold: float = 90.0,
) -> dict[str, pd.DataFrame]:
    parquet_dir = Path(parquet_dir)
    output_dir = Path(output_dir)
    parquet_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)

    datasets, diagnostics = load_clean_datasets(file_paths)

    for name, df in datasets.items():
        if not df.empty:
            write_parquet(df, parquet_dir / f"{name}.parquet")

    item_client_map, item_attrs = build_item_lookups(datasets["item_catalog"])
    write_parquet(item_client_map, parquet_dir / "item_client_map.parquet")
    write_parquet(item_attrs, parquet_dir / "item_attributes.parquet")

    current_sales, ly_sales = compute_sales_windows(
        datasets["weekly_sellout"],
        datasets["weekly_sellout_ly"],
    )

    kpis = compute_store_item_kpis(
        inventory=datasets["current_inventory"],
        current_sales=current_sales,
        ly_sales=ly_sales,
        forecast=datasets["forecast_6w"],
        valid_combos=datasets["valid_combos"],
        item_client_map=item_client_map,
        item_attrs=item_attrs,
        store_catalog=datasets["store_catalog"],
        forecast_horizon_weeks=forecast_horizon_weeks,
        fc_final_basis=fc_final_basis,
        include_in_transit=include_in_transit,
        include_in_whse=include_in_whse,
        include_on_order=include_on_order,
        target_coverage_days=target_coverage_days,
        overstock_doi_threshold=overstock_doi_threshold,
    )

    summaries = build_dashboard_summaries(kpis)

    write_parquet(kpis, parquet_dir / "store_item_kpis.parquet")
    export_csv(kpis, output_dir / "store_item_kpis.csv")
    export_csv(diagnostics, output_dir / "duplicate_diagnostics.csv")

    for name, df in summaries.items():
        write_parquet(df, parquet_dir / f"summary_{name}.parquet")
        export_csv(df, output_dir / f"summary_{name}.csv")

    return {
        "store_item_kpis": kpis,
        "duplicate_diagnostics": diagnostics,
        **{f"summary_{k}": v for k, v in summaries.items()},
    }
