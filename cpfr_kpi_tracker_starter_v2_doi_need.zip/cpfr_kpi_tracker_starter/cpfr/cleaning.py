from __future__ import annotations

import re
from typing import Dict, Iterable, List, Tuple

import numpy as np
import pandas as pd

from .constants import COLUMN_ALIASES, NUMERIC_COLUMNS, TRAIT_MAP


def normalize_header(col: str) -> str:
    """Normalize raw RL headers for alias matching."""
    col = str(col).strip().lower()
    col = re.sub(r"\s+", " ", col)
    return col


def lower_and_rename(df: pd.DataFrame, extra_aliases: Dict[str, str] | None = None) -> pd.DataFrame:
    """Lowercase/trim columns and apply canonical aliases."""
    aliases = dict(COLUMN_ALIASES)
    if extra_aliases:
        aliases.update({normalize_header(k): v for k, v in extra_aliases.items()})

    out = df.copy()
    normalized_cols = [normalize_header(c) for c in out.columns]
    out.columns = [aliases.get(c, c.replace(" ", "_")) for c in normalized_cols]
    return out


def normalize_keys(df: pd.DataFrame) -> pd.DataFrame:
    """Normalize store/SKU keys without converting them to floats."""
    out = df.copy()
    for key in ["store_id", "client_item_nbr", "item_id"]:
        if key in out.columns:
            out[key] = (
                out[key]
                .astype("string")
                .str.strip()
                .str.replace(r"\.0$", "", regex=True)
            )

    if "store_trait" in out.columns:
        raw = out["store_trait"].astype("string").str.strip()
        mapped = raw.map(TRAIT_MAP)
        out["store_trait"] = mapped.fillna(raw)

    return out


def coerce_numeric(df: pd.DataFrame, columns: Iterable[str] | None = None, nonnegative: bool = True) -> pd.DataFrame:
    """Convert numeric columns safely."""
    out = df.copy()
    cols = list(columns) if columns is not None else [c for c in NUMERIC_COLUMNS if c in out.columns]
    for c in cols:
        if c in out.columns:
            out[c] = pd.to_numeric(out[c], errors="coerce").fillna(0)
            if nonnegative:
                out[c] = out[c].clip(lower=0)
    return out


def standardize_forecast_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Convert forecast columns like 'Week 12 Forecast' into fc_wk_1..fc_wk_6
    based on left-to-right order.
    """
    out = df.copy()
    forecast_cols = []
    for c in out.columns:
        if re.match(r"fc_week_\d+", str(c)) or re.match(r"week_\d+_forecast", str(c)):
            forecast_cols.append(c)

    # Include any remaining columns with both week + forecast after basic normalization.
    for c in out.columns:
        lc = str(c).lower()
        if c not in forecast_cols and "week" in lc and "forecast" in lc:
            forecast_cols.append(c)

    # Keep original file order and rename first six.
    forecast_cols = forecast_cols[:6]
    rename_map = {c: f"fc_wk_{i+1}" for i, c in enumerate(forecast_cols)}
    out = out.rename(columns=rename_map)
    return out


def optimize_dtypes(df: pd.DataFrame) -> pd.DataFrame:
    """Lightweight dtype optimization for dashboard speed."""
    out = df.copy()
    category_candidates = [
        "store_id", "client_item_nbr", "item_id", "store_trait",
        "state", "region", "brand", "category", "subcategory", "year", "inline"
    ]
    for c in category_candidates:
        if c in out.columns:
            out[c] = out[c].astype("string")

    for c in out.select_dtypes(include=["float64"]).columns:
        out[c] = pd.to_numeric(out[c], downcast="float")
    for c in out.select_dtypes(include=["int64"]).columns:
        out[c] = pd.to_numeric(out[c], downcast="integer")
    return out


def clean_common(df: pd.DataFrame, extra_aliases: Dict[str, str] | None = None) -> pd.DataFrame:
    """Common cleaning pipeline."""
    out = lower_and_rename(df, extra_aliases=extra_aliases)
    out = standardize_forecast_columns(out)
    out = normalize_keys(out)
    out = coerce_numeric(out)
    out = optimize_dtypes(out)
    return out
