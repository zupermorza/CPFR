from __future__ import annotations

from pathlib import Path
from typing import Optional

import pandas as pd


def read_rl_txt(path: str | Path) -> pd.DataFrame:
    """
    Read RL txt/csv exports with separator auto-detection.
    Supports comma, tab, pipe, semicolon. Tries UTF-8 then Latin-1.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    errors = []
    for encoding in ["utf-8-sig", "latin-1"]:
        try:
            return pd.read_csv(
                path,
                sep=None,
                engine="python",
                encoding=encoding,
                dtype="string",
            )
        except Exception as exc:
            errors.append(f"{encoding}: {exc}")

    raise ValueError(f"Could not read {path}. Errors: {' | '.join(errors)}")


def read_any_table(path: str | Path) -> pd.DataFrame:
    """Read txt/csv/xlsx based on file extension."""
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix in [".txt", ".csv"]:
        return read_rl_txt(path)
    if suffix in [".xlsx", ".xls"]:
        return pd.read_excel(path, dtype="string")
    raise ValueError(f"Unsupported file extension: {suffix}")


def write_parquet(df: pd.DataFrame, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(path, index=False)
    return path


def read_parquet(path: str | Path) -> pd.DataFrame:
    return pd.read_parquet(path)


def export_csv(df: pd.DataFrame, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding="utf-8-sig")
    return path
