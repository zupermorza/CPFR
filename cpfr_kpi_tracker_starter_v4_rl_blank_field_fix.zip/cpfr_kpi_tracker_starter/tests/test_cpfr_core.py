import pandas as pd

from cpfr.aggregation import aggregate_duplicates
from cpfr.cleaning import clean_common
from cpfr.kpis import compute_cpfr_foundation_metrics, compute_store_item_kpis


def test_duplicate_aggregation_sums_values():
    df = pd.DataFrame({"store_id": ["1", "1"], "client_item_nbr": ["A", "A"], "on_hand": [2, 3]})
    out, diag = aggregate_duplicates(df, ["store_id", "client_item_nbr"], ["on_hand"], dataset="inv")
    assert len(out) == 1
    assert out.loc[0, "on_hand"] == 5
    assert diag.duplicated_keys == 1


def test_doi_instock_overstock_necesidad_logic():
    df = pd.DataFrame(
        {
            "sales_last4": [28, 1],
            "sales_ly_next4": [14, 1],
            "uxe": [10, 12],
            "on_hand": [100, 0],
            "in_transit": [0, 0],
            "in_whse": [0, 0],
            "on_order": [0, 0],
        }
    )
    out = compute_cpfr_foundation_metrics(df)
    assert out.loc[0, "demand_28d_units"] == 28
    assert out.loc[0, "daily_sellout_rate"] == 1
    assert out.loc[0, "doi_days"] == 100
    assert out.loc[0, "in_stock_flag"] == 1
    assert out.loc[0, "overstock_flag"] == 1
    assert out.loc[1, "necesidad"] == 24


def test_valid_combo_filter_applied_at_end():
    valid = pd.DataFrame({"store_id": ["1"], "client_item_nbr": ["A"]})
    inv = pd.DataFrame({"store_id": ["1", "2"], "client_item_nbr": ["A", "B"], "on_hand": [1, 1]})
    out = compute_store_item_kpis(
        inventory=inv,
        current_sales=pd.DataFrame(columns=["store_id", "client_item_nbr", "sales_last4", "sales_last6"]),
        ly_sales=pd.DataFrame(columns=["store_id", "client_item_nbr", "sales_ly_last4", "sales_ly_last6", "sales_ly_next4"]),
        forecast=pd.DataFrame(columns=["store_id", "client_item_nbr", "fc_wk_1", "fc_wk_2", "fc_wk_3", "fc_wk_4", "fc_wk_5", "fc_wk_6"]),
        valid_combos=valid,
        item_client_map=pd.DataFrame(columns=["client_item_nbr", "item_id"]),
        item_attrs=pd.DataFrame(columns=["item_id", "uxe"]),
        store_catalog=pd.DataFrame(columns=["store_id"]),
    )
    assert len(out) == 1
    assert out.loc[0, "store_id"] == "1"


def test_dynamic_forecast_column_detection():
    raw = pd.DataFrame({"Store Nbr": ["1"], "Item Nbr": ["A"], "Week 21 Forecast": [1], "Week 22 Forecast": [2]})
    cleaned = clean_common(raw)
    assert "fc_wk_1" in cleaned.columns and "fc_wk_2" in cleaned.columns


def test_headerless_weekly_sellout_schema_is_assigned(tmp_path):
    from cpfr.engine import load_clean_datasets

    weekly = tmp_path / "weekly.txt"
    weekly.write_text("1001,Doll A,10,Store A,9,202501,3,30,45\n", encoding="utf-8")

    datasets, _ = load_clean_datasets({"weekly_sellout": str(weekly)})
    out = datasets["weekly_sellout"]

    assert "client_item_nbr" in out.columns
    assert "store_id" in out.columns
    assert "wm_week" in out.columns
    assert "pos_qty" in out.columns
    assert out.loc[0, "client_item_nbr"] == "1001"
    assert out.loc[0, "store_id"] == "10"
    assert out.loc[0, "pos_qty"] == 3


def test_headerless_forecast_schema_is_assigned(tmp_path):
    from cpfr.engine import load_clean_datasets

    fcst = tmp_path / "forecast.txt"
    fcst.write_text("1001,Doll A,10,Store A,9,1,2,3,4,5,6\n", encoding="utf-8")

    datasets, _ = load_clean_datasets({"forecast_6w": str(fcst)})
    out = datasets["forecast_6w"]

    assert "fc_wk_1" in out.columns and "fc_wk_6" in out.columns
    assert out.loc[0, "fc_wk_1"] == 1
    assert out.loc[0, "fc_wk_6"] == 6
