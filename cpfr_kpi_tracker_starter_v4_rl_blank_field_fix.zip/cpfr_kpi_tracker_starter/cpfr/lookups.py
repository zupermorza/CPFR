from __future__ import annotations

import pandas as pd


def build_item_lookups(item_catalog: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Two-step lookup:
    1) client_item_nbr -> item_id
    2) item_id -> item attributes
    """
    if item_catalog.empty:
        return pd.DataFrame(columns=["client_item_nbr", "item_id"]), pd.DataFrame(columns=["item_id"])

    df = item_catalog.copy()

    client_cols = [c for c in ["client_item_nbr", "item_id"] if c in df.columns]
    if set(["client_item_nbr", "item_id"]).issubset(client_cols):
        client_map = df[["client_item_nbr", "item_id"]].dropna().drop_duplicates("client_item_nbr", keep="first")
    else:
        client_map = pd.DataFrame(columns=["client_item_nbr", "item_id"])

    attr_cols = [
        "item_id", "item_desc_catalog", "item_desc", "category", "brand",
        "subcategory", "year", "inline", "uxe", "cost"
    ]
    attr_cols = [c for c in attr_cols if c in df.columns]
    if "item_id" in attr_cols:
        attrs = df[attr_cols].drop_duplicates("item_id", keep="first")
    else:
        attrs = pd.DataFrame(columns=["item_id"])

    return client_map, attrs


def enrich_items(base: pd.DataFrame, client_map: pd.DataFrame, attrs: pd.DataFrame) -> pd.DataFrame:
    out = base.copy()
    if not client_map.empty:
        out = out.merge(client_map.drop_duplicates("client_item_nbr"), on="client_item_nbr", how="left")
    if not attrs.empty and "item_id" in out.columns:
        out = out.merge(attrs.drop_duplicates("item_id"), on="item_id", how="left", suffixes=("", "_attr"))
    return out


def enrich_stores(base: pd.DataFrame, store_catalog: pd.DataFrame) -> pd.DataFrame:
    out = base.copy()
    if store_catalog.empty or "store_id" not in store_catalog.columns:
        return out

    keep = [
        "store_id", "store_name_catalog", "store_name", "store_trait",
        "store_trait_original", "city", "state", "region"
    ]
    keep = [c for c in keep if c in store_catalog.columns]
    stores = store_catalog[keep].drop_duplicates("store_id", keep="first")

    # Avoid duplicate store_trait/store_name columns from operational files if catalog is available.
    overlap = [c for c in stores.columns if c in out.columns and c != "store_id"]
    out = out.drop(columns=overlap, errors="ignore")
    out = out.merge(stores, on="store_id", how="left")
    return out
