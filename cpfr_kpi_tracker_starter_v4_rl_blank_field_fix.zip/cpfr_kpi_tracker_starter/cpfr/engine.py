from __future__ import annotations

from pathlib import Path
from typing import Dict, Tuple

import pandas as pd

from .aggregation import aggregate_duplicates, diagnostics_to_frame
from .cleaning import clean_common, coerce_numeric
from .io import read_any_table, write_parquet, export_csv
from .constants import HEADERLESS_RL_SCHEMAS
from .lookups import build_item_lookups
from .kpis import compute_sales_windows, compute_store_item_kpis, build_dashboard_summaries


REQUIRED_COLUMNS = {
    "weekly_sellout": ["store_id", "client_item_nbr", "wm_week", "pos_qty"],
    "weekly_sellout_ly": ["store_id", "client_item_nbr", "wm_week", "pos_qty_ly"],
    "current_inventory": ["store_id", "client_item_nbr", "on_hand", "in_transit", "in_whse", "on_order"],
    "forecast_6w": ["store_id", "client_item_nbr"],
    "item_catalog": ["client_item_nbr"],
    "store_catalog": ["store_id"],
    "valid_combos": ["store_id", "client_item_nbr"],
}



def _read_source_table(dataset_name: str, path: str) -> pd.DataFrame:
    """
    Read source table.

    The first four RL operational exports are headerless positional files.
    Real RL TXT downloads may include an extra empty field immediately after
    Item Nbr, for example:
        701464<TAB><TAB>FP LEON ANDADERA<TAB>15...
    To avoid shifted columns, read raw first and then assign the matching
    schema based on detected column count.
    """
    if dataset_name in HEADERLESS_RL_SCHEMAS:
        schema = HEADERLESS_RL_SCHEMAS[dataset_name]
        raw = read_any_table(path, header=None, names=None)

        # Case A: actual RL structure with the blank placeholder column.
        if raw.shape[1] == len(schema):
            raw.columns = schema
            return raw

        # Case B: same file structure but without the extra blank field.
        schema_without_blank = [c for c in schema if not c.startswith("_rl_blank")]
        if raw.shape[1] == len(schema_without_blank):
            raw.columns = schema_without_blank
            return raw

        raise ValueError(
            f"{dataset_name}: expected {len(schema_without_blank)} columns "
            f"(normal headerless) or {len(schema)} columns (with RL blank field), "
            f"but detected {raw.shape[1]} columns. Check delimiter/file structure."
        )

    return read_any_table(path)


def _validate_columns(df: pd.DataFrame, dataset_name: str, required_cols: list[str]) -> None:
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        raise ValueError(
            f"{dataset_name}: required columns not recognized after cleaning: {missing}. "
            "Check file structure and delimiters. The first four RL operational exports are expected to be headerless positional files; catalogs/lookups are expected to have headers. Supported delimiters: comma, tab, pipe, semicolon."
        )


def _empty() -> pd.DataFrame:
    return pd.DataFrame()


def load_clean_datasets(file_paths: Dict[str, str]) -> tuple[dict[str, pd.DataFrame], pd.DataFrame]:
    """
    Read raw files and return cleaned, grain-correct datasets plus diagnostics.
    """
    diags = []
    out: dict[str, pd.DataFrame] = {}

    # 1) Current weekly sell-out
    if file_paths.get("weekly_sellout"):
        df = clean_common(_read_source_table("weekly_sellout", file_paths["weekly_sellout"]))
        _validate_columns(df, "weekly_sellout", REQUIRED_COLUMNS["weekly_sellout"])
        df, d = aggregate_duplicates(
            df,
            keys=["store_id", "client_item_nbr", "wm_week"],
            sum_cols=["pos_qty", "pos_cost", "pos_sales"],
            keep_cols=["item_desc", "store_name", "store_trait"],
            dataset="weekly_sellout",
        )
        out["weekly_sellout"] = df
        diags.append(d)
    else:
        out["weekly_sellout"] = _empty()

    # 2) Last year's weekly sell-out
    if file_paths.get("weekly_sellout_ly"):
        df = clean_common(_read_source_table("weekly_sellout_ly", file_paths["weekly_sellout_ly"]))
        df = df.rename(columns={"pos_qty": "pos_qty_ly", "pos_cost": "pos_cost_ly", "pos_sales": "pos_sales_ly"})
        _validate_columns(df, "weekly_sellout_ly", REQUIRED_COLUMNS["weekly_sellout_ly"])
        df = coerce_numeric(df, ["pos_qty_ly", "pos_cost_ly", "pos_sales_ly"])
        df, d = aggregate_duplicates(
            df,
            keys=["store_id", "client_item_nbr", "wm_week"],
            sum_cols=["pos_qty_ly", "pos_cost_ly", "pos_sales_ly"],
            keep_cols=["item_desc", "store_name", "store_trait"],
            dataset="weekly_sellout_ly",
        )
        out["weekly_sellout_ly"] = df
        diags.append(d)
    else:
        out["weekly_sellout_ly"] = _empty()

    # 3) Current inventory
    if file_paths.get("current_inventory"):
        df = clean_common(_read_source_table("current_inventory", file_paths["current_inventory"]))
        _validate_columns(df, "current_inventory", REQUIRED_COLUMNS["current_inventory"])
        df, d = aggregate_duplicates(
            df,
            keys=["store_id", "client_item_nbr"],
            sum_cols=["on_hand", "in_transit", "in_whse", "on_order"],
            keep_cols=["item_desc", "store_name", "store_trait"],
            dataset="current_inventory",
        )
        out["current_inventory"] = df
        diags.append(d)
    else:
        out["current_inventory"] = _empty()

    # 4) Forecast 6W
    if file_paths.get("forecast_6w"):
        df = clean_common(_read_source_table("forecast_6w", file_paths["forecast_6w"]))
        _validate_columns(df, "forecast_6w", REQUIRED_COLUMNS["forecast_6w"])
        if not any(c.startswith("fc_wk_") for c in df.columns):
            raise ValueError("forecast_6w: no forecast week columns detected. Expected columns like 'Week 12 Forecast'.")
        fc_cols = [f"fc_wk_{i}" for i in range(1, 7)]
        df, d = aggregate_duplicates(
            df,
            keys=["store_id", "client_item_nbr"],
            sum_cols=fc_cols,
            keep_cols=["item_desc", "store_name", "store_trait"],
            dataset="forecast_6w",
        )
        out["forecast_6w"] = df
        diags.append(d)
    else:
        out["forecast_6w"] = _empty()

    # 5) Item catalog
    if file_paths.get("item_catalog"):
        item_catalog = clean_common(_read_source_table("item_catalog", file_paths["item_catalog"]))
        _validate_columns(item_catalog, "item_catalog", REQUIRED_COLUMNS["item_catalog"])
        out["item_catalog"] = item_catalog
    else:
        out["item_catalog"] = _empty()

    # 6) Store catalog
    if file_paths.get("store_catalog"):
        store_catalog = clean_common(_read_source_table("store_catalog", file_paths["store_catalog"]))
        _validate_columns(store_catalog, "store_catalog", REQUIRED_COLUMNS["store_catalog"])
        if "store_id" in store_catalog.columns:
            store_catalog = store_catalog.drop_duplicates("store_id", keep="first")
        out["store_catalog"] = store_catalog
    else:
        out["store_catalog"] = _empty()

    # 7) Subcategory-store LY
    if file_paths.get("subcat_store_ly"):
        sub = clean_common(_read_source_table("subcat_store_ly", file_paths["subcat_store_ly"]))
        if "subcat_store_id" in sub.columns:
            extracted = sub["subcat_store_id"].astype(str).str.extract(r"^(\d+)(.*)$")
            sub["store_id"] = extracted[0].astype("string").str.strip()
            sub["subcategory"] = extracted[1].astype("string").str.strip()
        out["subcat_store_ly"] = sub
    else:
        out["subcat_store_ly"] = _empty()

    # 8) Valid combos
    if file_paths.get("valid_combos"):
        valid = clean_common(_read_source_table("valid_combos", file_paths["valid_combos"]))
        _validate_columns(valid, "valid_combos", REQUIRED_COLUMNS["valid_combos"])
        valid = valid[["store_id", "client_item_nbr"]].drop_duplicates()
        out["valid_combos"] = valid
    else:
        out["valid_combos"] = _empty()

    return out, diagnostics_to_frame(diags)


def run_pipeline(
    file_paths: Dict[str, str],
    parquet_dir: str | Path = "data/parquet",
    output_dir: str | Path = "data/outputs",
    forecast_horizon_weeks: int = 6,
    fc_final_basis: str = "n6w",
    include_in_transit: bool = True,
    include_in_whse: bool = True,
    include_on_order: bool = False,
    target_coverage_days: int = 28,
    overstock_doi_threshold: float = 90.0,
) -> dict[str, pd.DataFrame]:
    parquet_dir = Path(parquet_dir)
    output_dir = Path(output_dir)
    parquet_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)

    datasets, diagnostics = load_clean_datasets(file_paths)

    for name, df in datasets.items():
        if not df.empty:
            write_parquet(df, parquet_dir / f"{name}.parquet")

    item_client_map, item_attrs = build_item_lookups(datasets["item_catalog"])
    write_parquet(item_client_map, parquet_dir / "item_client_map.parquet")
    write_parquet(item_attrs, parquet_dir / "item_attributes.parquet")

    current_sales, ly_sales = compute_sales_windows(
        datasets["weekly_sellout"],
        datasets["weekly_sellout_ly"],
    )

    kpis = compute_store_item_kpis(
        inventory=datasets["current_inventory"],
        current_sales=current_sales,
        ly_sales=ly_sales,
        forecast=datasets["forecast_6w"],
        valid_combos=datasets["valid_combos"],
        item_client_map=item_client_map,
        item_attrs=item_attrs,
        store_catalog=datasets["store_catalog"],
        forecast_horizon_weeks=forecast_horizon_weeks,
        fc_final_basis=fc_final_basis,
        include_in_transit=include_in_transit,
        include_in_whse=include_in_whse,
        include_on_order=include_on_order,
        target_coverage_days=target_coverage_days,
        overstock_doi_threshold=overstock_doi_threshold,
    )

    summaries = build_dashboard_summaries(kpis)

    write_parquet(kpis, parquet_dir / "store_item_kpis.parquet")
    export_csv(kpis, output_dir / "store_item_kpis.csv")
    export_csv(diagnostics, output_dir / "duplicate_diagnostics.csv")

    for name, df in summaries.items():
        write_parquet(df, parquet_dir / f"summary_{name}.parquet")
        export_csv(df, output_dir / f"summary_{name}.csv")

    return {
        "store_item_kpis": kpis,
        "duplicate_diagnostics": diagnostics,
        **{f"summary_{k}": v for k, v in summaries.items()},
    }
