from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

# Canonical hierarchy used in the first dashboard summary.
SUMMARY_ROWS_TRAIT = ["SC", "BA", "MIBO", "BAE", "TOTAL"]
SUMMARY_ROWS_GRS1 = ["DOLLS", "VEHICLES", "GAMES", "AF", "BS"]

TRAIT_MAP = {
    "9": "BA",
    "1312": "MIBO",
    "969": "BAE",
    "297": "SC",
    9: "BA",
    1312: "MIBO",
    969: "BAE",
    297: "SC",
}


# Headerless RL TXT export schemas for the four operational files.
# RL downloads for these files contain no header row; columns are positional.
HEADERLESS_RL_SCHEMAS: Dict[str, List[str]] = {
    # IMPORTANT:
    # The RL headerless TXT operational extracts contain an extra empty field
    # immediately after Item Nbr. Example:
    #   701464<TAB><TAB>FP LEON ANDADERA<TAB>15<...>
    # Therefore we keep a positional placeholder "_rl_blank_1" so every later
    # column lands in the correct canonical field.
    "weekly_sellout": [
        "client_item_nbr", "_rl_blank_1", "item_desc", "store_id", "store_name", "store_trait",
        "wm_week", "pos_qty", "pos_cost", "pos_sales",
    ],
    "weekly_sellout_ly": [
        "client_item_nbr", "_rl_blank_1", "item_desc", "store_id", "store_name", "store_trait",
        "wm_week", "pos_qty", "pos_cost", "pos_sales",
    ],
    "current_inventory": [
        "client_item_nbr", "_rl_blank_1", "item_desc", "store_id", "store_name", "store_trait",
        "on_hand", "in_transit", "in_whse", "on_order",
    ],
    "forecast_6w": [
        "client_item_nbr", "_rl_blank_1", "item_desc", "store_id", "store_name", "store_trait",
        "fc_wk_1", "fc_wk_2", "fc_wk_3", "fc_wk_4", "fc_wk_5", "fc_wk_6",
    ],
}

# Raw column aliases -> canonical names.
COLUMN_ALIASES: Dict[str, str] = {
    # Shared RL columns
    "item nbr": "client_item_nbr",
    "item number": "client_item_nbr",
    "item_nbr": "client_item_nbr",
    "item desc 1": "item_desc",
    "item descr 1": "item_desc_catalog",
    "store nbr": "store_id",
    "str_nbr": "store_id",
    "store number": "store_id",
    "store name": "store_name",
    "str_name": "store_name_catalog",
    "sel store trait": "store_trait",
    "store trait": "store_trait_original",
    "wm week": "wm_week",
    "pos qty": "pos_qty",
    "pos cost": "pos_cost",
    "pos sales": "pos_sales",

    # Current inventory
    "curr str on hand qty": "on_hand",
    "curr str in transit qty": "in_transit",
    "curr str in whse qty": "in_whse",
    "curr str on order qty": "on_order",

    # Forecast: dynamic columns also handled in cleaning.standardize_forecast_columns()
    "week 12 forecast": "fc_week_12",
    "week 13 forecast": "fc_week_13",
    "week 14 forecast": "fc_week_14",
    "week 15 forecast": "fc_week_15",
    "week 16 forecast": "fc_week_16",
    "week 17 forecast": "fc_week_17",

    # Item catalog
    "item mattel": "item_id",
    "uxe": "uxe",
    "cost": "cost",
    "category": "category",
    "brand": "brand",
    "subcategory": "subcategory",
    "sub category": "subcategory",
    "sub-category": "subcategory",
    "año": "year",
    "ano": "year",
    "inline": "inline",

    # Store catalog
    "ciudad": "city",
    "estado": "state",
    "región": "region",
    "region": "region",

    # Subcat store LY
    "subcategory-store id": "subcat_store_id",
    "store-subcategory id": "subcat_store_id",
    "last year's retail sell-out": "ly_subcat_store_sales",
    "last years retail sell-out": "ly_subcat_store_sales",
    "last year retail sell-out": "ly_subcat_store_sales",
}

NUMERIC_COLUMNS = [
    "pos_qty", "pos_cost", "pos_sales",
    "pos_qty_ly", "pos_cost_ly", "pos_sales_ly",
    "on_hand", "in_transit", "in_whse", "on_order",
    "fc_wk_1", "fc_wk_2", "fc_wk_3", "fc_wk_4", "fc_wk_5", "fc_wk_6",
    "n4w", "n6w", "fc_final", "sales_last4", "sales_last6",
    "sales_ly_last4", "sales_ly_last6", "sales_ly_next4",
    "inventory_position", "demand_28d_units", "daily_sellout_rate", "doi_days",
    "target_inventory_units_raw", "necesidad_raw_units", "necesidad_packages", "necesidad",
    "in_stock_flag", "overstock_flag", "under_1_pkg", "under_3_pkg", "over_3_pkg",
    "uxe", "cost", "ly_subcat_store_sales",
]

KEY_COLUMNS = ["store_id", "client_item_nbr", "item_id"]

SUMMARY_COLUMNS = [
    "section",
    "group",
    "total_combinations",
    "total_inventory",
    "instock_pct",
    "overstock_pct",
    "doi_days",
    "combos_under_1_pkg",
    "combos_under_3_pkg",
    "combos_over_3_pkg",
    "necesidad",
]
