from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Tuple

import pandas as pd


@dataclass
class DuplicateDiagnostics:
    dataset: str
    key_columns: List[str]
    total_rows: int
    unique_keys: int
    duplicated_keys: int
    duplicate_key_rate: float
    top_duplicates: pd.DataFrame


def aggregate_duplicates(
    df: pd.DataFrame,
    keys: List[str],
    sum_cols: Iterable[str],
    dataset: str,
    keep_cols: Iterable[str] | None = None,
) -> tuple[pd.DataFrame, DuplicateDiagnostics]:
    """
    Aggregate duplicate combinations at the declared grain.
    Numeric columns are summed; selected descriptive columns keep first.
    """
    if df.empty:
        diag = DuplicateDiagnostics(dataset, keys, 0, 0, 0, 0.0, pd.DataFrame(columns=keys + ["row_count"]))
        return df.copy(), diag

    missing = [c for c in keys if c not in df.columns]
    if missing:
        raise ValueError(f"{dataset}: missing key columns {missing}")

    key_counts = df.groupby(keys, dropna=False, observed=True).size().rename("row_count")
    duplicated_keys = int((key_counts > 1).sum())
    unique_keys = int(key_counts.shape[0])
    total_rows = int(len(df))
    duplicate_key_rate = duplicated_keys / unique_keys if unique_keys else 0.0
    top = key_counts.sort_values(ascending=False).head(25).reset_index()

    agg_dict: Dict[str, str] = {}
    for c in sum_cols:
        if c in df.columns:
            agg_dict[c] = "sum"

    if keep_cols:
        for c in keep_cols:
            if c in df.columns and c not in keys and c not in agg_dict:
                agg_dict[c] = "first"

    out = df.groupby(keys, dropna=False, as_index=False, observed=True).agg(agg_dict)

    diag = DuplicateDiagnostics(
        dataset=dataset,
        key_columns=keys,
        total_rows=total_rows,
        unique_keys=unique_keys,
        duplicated_keys=duplicated_keys,
        duplicate_key_rate=duplicate_key_rate,
        top_duplicates=top,
    )
    return out, diag


def diagnostics_to_frame(diags: list[DuplicateDiagnostics]) -> pd.DataFrame:
    return pd.DataFrame([
        {
            "dataset": d.dataset,
            "key_columns": ", ".join(d.key_columns),
            "total_rows": d.total_rows,
            "unique_keys": d.unique_keys,
            "duplicated_keys": d.duplicated_keys,
            "duplicate_key_rate": d.duplicate_key_rate,
        }
        for d in diags
    ])
