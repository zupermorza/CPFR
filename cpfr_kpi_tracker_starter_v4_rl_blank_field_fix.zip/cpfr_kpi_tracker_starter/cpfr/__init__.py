"""CPFR KPI Tracker package."""
