from __future__ import annotations

import numpy as np
import pandas as pd

from .constants import SUMMARY_COLUMNS


def latest_n_weeks(df: pd.DataFrame, n: int, week_col: str = "wm_week") -> pd.DataFrame:
    if df.empty or week_col not in df.columns:
        return df.iloc[0:0].copy()

    weeks = (
        pd.to_numeric(df[week_col], errors="coerce")
        .dropna()
        .sort_values()
        .unique()
    )
    selected = set(weeks[-n:])
    return df[pd.to_numeric(df[week_col], errors="coerce").isin(selected)].copy()


def compute_sales_windows(current_sellout: pd.DataFrame, ly_sellout: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Create store-item sales_last4/6 and sales_ly_last4/6 tables."""
    keys = ["store_id", "client_item_nbr"]

    if current_sellout.empty:
        current = pd.DataFrame(columns=keys + ["sales_last4", "sales_last6"])
    else:
        l4 = latest_n_weeks(current_sellout, 4).groupby(keys, as_index=False, observed=True)["pos_qty"].sum()
        l4 = l4.rename(columns={"pos_qty": "sales_last4"})
        l6 = latest_n_weeks(current_sellout, 6).groupby(keys, as_index=False, observed=True)["pos_qty"].sum()
        l6 = l6.rename(columns={"pos_qty": "sales_last6"})
        current = l6.merge(l4, on=keys, how="outer").fillna({"sales_last4": 0, "sales_last6": 0})

    if ly_sellout.empty:
        ly = pd.DataFrame(columns=keys + ["sales_ly_last4", "sales_ly_last6", "sales_ly_next4"])
    else:
        qty_col = "pos_qty_ly" if "pos_qty_ly" in ly_sellout.columns else "pos_qty"
        l4ly = latest_n_weeks(ly_sellout, 4).groupby(keys, as_index=False, observed=True)[qty_col].sum()
        l4ly = l4ly.rename(columns={qty_col: "sales_ly_last4"})
        l6ly = latest_n_weeks(ly_sellout, 6).groupby(keys, as_index=False, observed=True)[qty_col].sum()
        l6ly = l6ly.rename(columns={qty_col: "sales_ly_last6"})
        ly = l6ly.merge(l4ly, on=keys, how="outer").fillna({"sales_ly_last4": 0, "sales_ly_last6": 0})
        # Business naming: this is the comparable next-4-week LY demand window loaded in the LY file.
        ly["sales_ly_next4"] = ly["sales_ly_last4"]

    return current, ly


def compute_forecast_totals(forecast: pd.DataFrame, fc_final_basis: str = "n6w") -> pd.DataFrame:
    out = forecast.copy()
    for c in [f"fc_wk_{i}" for i in range(1, 7)]:
        if c not in out.columns:
            out[c] = 0.0

    out["n4w"] = out[["fc_wk_1", "fc_wk_2", "fc_wk_3", "fc_wk_4"]].sum(axis=1)
    out["n6w"] = out[[f"fc_wk_{i}" for i in range(1, 7)]].sum(axis=1)
    out["fc_final"] = out["n4w"] if fc_final_basis == "n4w" else out["n6w"]
    return out


def _clean_uxe(df: pd.DataFrame) -> pd.Series:
    """UxE/package size must never be zero because it drives package rounding."""
    if "uxe" not in df.columns:
        return pd.Series(1.0, index=df.index)
    uxe = pd.to_numeric(df["uxe"], errors="coerce").fillna(1.0)
    return uxe.where(uxe > 0, 1.0)


def compute_inventory_position(
    df: pd.DataFrame,
    include_in_transit: bool = True,
    include_in_whse: bool = True,
    include_on_order: bool = False,
) -> pd.Series:
    """
    Total inventory available for KPI evaluation.

    Default excludes on_order, per business rule. In transit and warehouse are included
    because they are already within the current total inventory extract and can be turned
    off later from config if the team wants a stricter on-hand-only KPI.
    """
    pos = pd.to_numeric(df.get("on_hand", 0), errors="coerce").fillna(0)
    if include_in_transit and "in_transit" in df.columns:
        pos = pos + pd.to_numeric(df["in_transit"], errors="coerce").fillna(0)
    if include_in_whse and "in_whse" in df.columns:
        pos = pos + pd.to_numeric(df["in_whse"], errors="coerce").fillna(0)
    if include_on_order and "on_order" in df.columns:
        pos = pos + pd.to_numeric(df["on_order"], errors="coerce").fillna(0)
    return pos.clip(lower=0)


def compute_cpfr_foundation_metrics(
    df: pd.DataFrame,
    include_in_transit: bool = True,
    include_in_whse: bool = True,
    include_on_order: bool = False,
    target_coverage_days: int = 28,
    overstock_doi_threshold: float = 90.0,
) -> pd.DataFrame:
    """
    Compute the first production KPI policy:

    demand_28d_units = max(
        sales_last4,
        sales_ly_next4,
        2 * UxE
    )

    daily_sellout_rate = demand_28d_units / 28
    doi_days = inventory_position / daily_sellout_rate

    InStock flag:
        inventory_position > daily_sellout_rate

    OverStock flag:
        only when inventory_position > 2 * UxE, flag if doi_days > 90

    Necesidad:
        target_coverage_days of the same daily rate less current inventory position,
        rounded up to full packages/UxE because shipments move in packages.
    """
    out = df.copy()
    out["uxe"] = _clean_uxe(out)

    out["inventory_position"] = compute_inventory_position(
        out,
        include_in_transit=include_in_transit,
        include_in_whse=include_in_whse,
        include_on_order=include_on_order,
    )

    sales_last4 = pd.to_numeric(out.get("sales_last4", 0), errors="coerce").fillna(0)
    # sales_ly_next4 is created as a semantic alias of the LY comparable 4-week sell-out.
    if "sales_ly_next4" in out.columns:
        ly_next4 = pd.to_numeric(out["sales_ly_next4"], errors="coerce").fillna(0)
    else:
        ly_next4 = pd.to_numeric(out.get("sales_ly_last4", 0), errors="coerce").fillna(0)

    min_two_packages = 2.0 * out["uxe"]

    out["demand_28d_units"] = np.maximum.reduce([
        sales_last4.to_numpy(dtype="float64"),
        ly_next4.to_numpy(dtype="float64"),
        min_two_packages.to_numpy(dtype="float64"),
    ])
    out["daily_sellout_rate"] = out["demand_28d_units"] / 28.0

    out["doi_days"] = np.where(
        out["daily_sellout_rate"] > 0,
        out["inventory_position"] / out["daily_sellout_rate"],
        np.nan,
    )

    out["in_stock_flag"] = (out["inventory_position"] > out["daily_sellout_rate"]).astype(int)
    out["under_1_pkg"] = (out["inventory_position"] < out["uxe"]).astype(int)
    out["under_3_pkg"] = (out["inventory_position"] < (3.0 * out["uxe"])).astype(int)
    out["over_3_pkg"] = (out["inventory_position"] > (3.0 * out["uxe"])).astype(int)

    out["overstock_flag"] = (
        (out["inventory_position"] > (2.0 * out["uxe"])) &
        (out["doi_days"] > overstock_doi_threshold)
    ).astype(int)

    out["target_inventory_units_raw"] = out["daily_sellout_rate"] * float(target_coverage_days)
    out["necesidad_raw_units"] = np.maximum(0, out["target_inventory_units_raw"] - out["inventory_position"])

    # Round need up to the next full package. If there is no need, keep zero.
    packages_needed = np.where(
        out["necesidad_raw_units"] > 0,
        np.ceil(out["necesidad_raw_units"] / out["uxe"]),
        0,
    )
    out["necesidad_packages"] = packages_needed.astype(int)
    out["necesidad"] = out["necesidad_packages"] * out["uxe"]

    return out


def compute_store_item_kpis(
    inventory: pd.DataFrame,
    current_sales: pd.DataFrame,
    ly_sales: pd.DataFrame,
    forecast: pd.DataFrame,
    valid_combos: pd.DataFrame,
    item_client_map: pd.DataFrame,
    item_attrs: pd.DataFrame,
    store_catalog: pd.DataFrame,
    forecast_horizon_weeks: int = 6,
    fc_final_basis: str = "n6w",
    include_in_transit: bool = True,
    include_in_whse: bool = True,
    include_on_order: bool = False,
    target_coverage_days: int = 28,
    overstock_doi_threshold: float = 90.0,
) -> pd.DataFrame:
    from .lookups import enrich_items, enrich_stores

    keys = ["store_id", "client_item_nbr"]
    base = valid_combos[keys].drop_duplicates().copy() if not valid_combos.empty else inventory[keys].drop_duplicates().copy()

    base = base.merge(inventory, on=keys, how="left")
    base = base.merge(current_sales, on=keys, how="left")
    base = base.merge(ly_sales, on=keys, how="left")

    forecast2 = compute_forecast_totals(forecast, fc_final_basis=fc_final_basis)
    forecast_cols = keys + [f"fc_wk_{i}" for i in range(1, 7)] + ["n4w", "n6w", "fc_final"]
    forecast_cols = [c for c in forecast_cols if c in forecast2.columns]
    base = base.merge(forecast2[forecast_cols], on=keys, how="left")

    fill_zero = [
        "on_hand", "in_transit", "in_whse", "on_order",
        "sales_last4", "sales_last6", "sales_ly_last4", "sales_ly_last6", "sales_ly_next4",
        "n4w", "n6w", "fc_final",
    ] + [f"fc_wk_{i}" for i in range(1, 7)]
    for c in fill_zero:
        if c in base.columns:
            base[c] = pd.to_numeric(base[c], errors="coerce").fillna(0)

    base = enrich_items(base, item_client_map, item_attrs)
    base = enrich_stores(base, store_catalog)

    base = compute_cpfr_foundation_metrics(
        base,
        include_in_transit=include_in_transit,
        include_in_whse=include_in_whse,
        include_on_order=include_on_order,
        target_coverage_days=target_coverage_days,
        overstock_doi_threshold=overstock_doi_threshold,
    )
    base["valid_combo_flag"] = True

    # Prefer catalog description if available.
    if "item_desc_catalog" in base.columns:
        if "item_desc" not in base.columns:
            base["item_desc"] = base["item_desc_catalog"]
        else:
            base["item_desc"] = base["item_desc"].fillna(base["item_desc_catalog"])

    preferred = [
        "store_id", "store_name", "store_name_catalog", "client_item_nbr", "item_id", "item_desc",
        "brand", "category", "subcategory", "year", "inline", "store_trait", "city", "state", "region",
        "uxe", "cost",
        "on_hand", "in_transit", "in_whse", "on_order", "inventory_position",
        "sales_last4", "sales_last6", "sales_ly_last4", "sales_ly_last6", "sales_ly_next4",
        "fc_wk_1", "fc_wk_2", "fc_wk_3", "fc_wk_4", "fc_wk_5", "fc_wk_6",
        "n4w", "n6w", "fc_final",
        "demand_28d_units", "daily_sellout_rate", "doi_days",
        "in_stock_flag", "overstock_flag",
        "under_1_pkg", "under_3_pkg", "over_3_pkg",
        "target_inventory_units_raw", "necesidad_raw_units", "necesidad_packages", "necesidad",
        "valid_combo_flag",
    ]
    cols = [c for c in preferred if c in base.columns] + [c for c in base.columns if c not in preferred]
    return base[cols]


def build_summary(df: pd.DataFrame, group_col: str, section_name: str) -> pd.DataFrame:
    """Build KPI Tracker summary matrix from precomputed store-SKU KPI flags."""
    if df.empty or group_col not in df.columns:
        return pd.DataFrame(columns=SUMMARY_COLUMNS)

    tmp = df.copy()
    tmp[group_col] = tmp[group_col].fillna("Unknown").astype(str)

    required_defaults = {
        "inventory_position": 0,
        "in_stock_flag": 0,
        "overstock_flag": 0,
        "under_1_pkg": 0,
        "under_3_pkg": 0,
        "over_3_pkg": 0,
        "necesidad": 0,
        "doi_days": np.nan,
    }
    for col, default in required_defaults.items():
        if col not in tmp.columns:
            tmp[col] = default

    g = tmp.groupby(group_col, dropna=False, as_index=False, observed=True).agg(
        total_combinations=("client_item_nbr", "count"),
        total_inventory=("inventory_position", "sum"),
        in_stock_combos=("in_stock_flag", "sum"),
        overstock_combos=("overstock_flag", "sum"),
        combos_under_1_pkg=("under_1_pkg", "sum"),
        combos_under_3_pkg=("under_3_pkg", "sum"),
        combos_over_3_pkg=("over_3_pkg", "sum"),
        necesidad=("necesidad", "sum"),
        doi_days=("doi_days", "mean"),
    )

    g["instock_pct"] = np.where(g["total_combinations"] > 0, g["in_stock_combos"] / g["total_combinations"], np.nan)
    g["overstock_pct"] = np.where(g["total_combinations"] > 0, g["overstock_combos"] / g["total_combinations"], np.nan)
    g = g.rename(columns={group_col: "group"})
    g["section"] = section_name

    total_combos = g["total_combinations"].sum()
    total = pd.DataFrame([{
        "section": section_name,
        "group": "TOTAL",
        "total_combinations": total_combos,
        "total_inventory": g["total_inventory"].sum(),
        "instock_pct": (g["in_stock_combos"].sum() / total_combos if total_combos else np.nan),
        "overstock_pct": (g["overstock_combos"].sum() / total_combos if total_combos else np.nan),
        "doi_days": tmp["doi_days"].mean(),
        "combos_under_1_pkg": g["combos_under_1_pkg"].sum(),
        "combos_under_3_pkg": g["combos_under_3_pkg"].sum(),
        "combos_over_3_pkg": g["combos_over_3_pkg"].sum(),
        "necesidad": g["necesidad"].sum(),
    }])

    out = pd.concat([g, total], ignore_index=True)
    return out[SUMMARY_COLUMNS]


def build_dashboard_summaries(df: pd.DataFrame) -> dict[str, pd.DataFrame]:
    return {
        "by_store_trait": build_summary(df, "store_trait", "SEL STORE TRAIT"),
        "by_category": build_summary(df, "category", "GRS1"),
        "by_brand": build_summary(df, "brand", "BRAND"),
        "by_subcategory": build_summary(df, "subcategory", "SUBCATEGORY"),
        "by_state": build_summary(df, "state", "STATE"),
    }
